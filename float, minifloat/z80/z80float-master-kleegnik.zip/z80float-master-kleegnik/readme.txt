https://github.com/kleegnik/z80float

IEEE floating-point arithmetic routines in Z80
