Slightly modified demo by Daniel A. Nagy

https://github.com/nagydani/lpfp/tree/master/raytracing
