# Common Routines
Here are routines that are used in common. For example, `mul16` is used by the
`f24` and `extended` libraries, and `sqrt16` is used by all, and string
conversion has similar subroutines.
