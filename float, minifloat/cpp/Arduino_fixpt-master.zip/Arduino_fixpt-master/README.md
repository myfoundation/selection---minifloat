Arduino_fixpt
=============

Fixed point (16.16 & 8.8) library for Arduino to replace resource hungry float/double.
Implementation based on libfixmath (https://code.google.com/p/libfixmath).
See also http://en.wikipedia.org/wiki/Libfixmath.

Released under MIT License.
